--
-- PostgreSQL database dump
--

\restrict ldrqz5BoSiuvMbhW14sy9zIt3dtfiToQK4xnIql3XaOde8yfpGaf0fqJgppFvnl

-- Dumped from database version 17.7 (Debian 17.7-3.pgdg13+1)
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: enum__home_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__home_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__home_v_version_status OWNER TO postgres;

--
-- Name: enum__pages_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__pages_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__pages_v_version_status OWNER TO postgres;

--
-- Name: enum__posts_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__posts_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__posts_v_version_status OWNER TO postgres;

--
-- Name: enum_form_field_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_form_field_type AS ENUM (
    'text',
    'textarea',
    'email',
    'number',
    'radio',
    'checkbox',
    'select',
    'date',
    'message'
);


ALTER TYPE public.enum_form_field_type OWNER TO postgres;

--
-- Name: enum_form_submission_confirmation_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_form_submission_confirmation_type AS ENUM (
    'redirect',
    'message'
);


ALTER TYPE public.enum_form_submission_confirmation_type OWNER TO postgres;

--
-- Name: enum_home_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_home_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_home_status OWNER TO postgres;

--
-- Name: enum_media_fit; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_media_fit AS ENUM (
    'cover',
    'contain',
    'fill',
    'inside',
    'outside'
);


ALTER TYPE public.enum_media_fit OWNER TO postgres;

--
-- Name: enum_menu_item_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_menu_item_type AS ENUM (
    'url',
    'internal',
    'custom',
    'passive'
);


ALTER TYPE public.enum_menu_item_type OWNER TO postgres;

--
-- Name: enum_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_pages_status OWNER TO postgres;

--
-- Name: enum_payload_jobs_log_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_payload_jobs_log_state AS ENUM (
    'failed',
    'succeeded'
);


ALTER TYPE public.enum_payload_jobs_log_state OWNER TO postgres;

--
-- Name: enum_payload_jobs_log_task_slug; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_payload_jobs_log_task_slug AS ENUM (
    'inline',
    'schedulePublish'
);


ALTER TYPE public.enum_payload_jobs_log_task_slug OWNER TO postgres;

--
-- Name: enum_payload_jobs_task_slug; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_payload_jobs_task_slug AS ENUM (
    'inline',
    'schedulePublish'
);


ALTER TYPE public.enum_payload_jobs_task_slug OWNER TO postgres;

--
-- Name: enum_posts_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_posts_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_posts_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _home_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._home_v (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_title character varying,
    version_meta_title character varying,
    version_meta_description character varying,
    version_meta_image_id uuid,
    version__status public.enum__home_v_version_status DEFAULT 'draft'::public.enum__home_v_version_status,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._home_v OWNER TO postgres;

--
-- Name: _pages_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._pages_v (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_id uuid,
    version__order character varying,
    version_title character varying,
    version_meta_title character varying,
    version_meta_description character varying,
    version_meta_image_id uuid,
    version_generate_slug boolean DEFAULT true,
    version_slug character varying,
    version_author_id uuid,
    version_parent_id uuid,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__pages_v_version_status DEFAULT 'draft'::public.enum__pages_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._pages_v OWNER TO postgres;

--
-- Name: _pages_v_version_breadcrumbs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._pages_v_version_breadcrumbs (
    _order integer NOT NULL,
    _parent_id uuid NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_id uuid,
    url character varying,
    label character varying,
    _uuid character varying
);


ALTER TABLE public._pages_v_version_breadcrumbs OWNER TO postgres;

--
-- Name: _posts_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._posts_v (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_id uuid,
    version_title character varying,
    version_generate_slug boolean DEFAULT true,
    version_slug character varying,
    version_author_id uuid,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__posts_v_version_status DEFAULT 'draft'::public.enum__posts_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._posts_v OWNER TO postgres;

--
-- Name: form; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying NOT NULL,
    generate_slug boolean DEFAULT true,
    slug character varying NOT NULL,
    form_submit_button_label character varying DEFAULT 'Submit'::character varying NOT NULL,
    submission_confirmation_type public.enum_form_submission_confirmation_type,
    submission_confirmation_message jsonb,
    submission_redirect_url character varying,
    handle character varying DEFAULT 'L5GSlobUDObBXuPF9TiCS'::character varying NOT NULL,
    pages jsonb DEFAULT '[{"id": "gxypC5OJkwAYwoCkwzbMe", "rows": [{"id": "RsTuwYawyD7dR9qLokLNS"}], "title": "Page 1", "backButton": "Back", "nextButton": "Next"}]'::jsonb,
    form_data jsonb,
    form_schema jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.form OWNER TO postgres;

--
-- Name: form_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_field (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying NOT NULL,
    handle character varying NOT NULL,
    page_id character varying NOT NULL,
    row_index numeric NOT NULL,
    column_index numeric NOT NULL,
    type public.enum_form_field_type NOT NULL,
    name character varying NOT NULL,
    label character varying NOT NULL,
    error_message character varying,
    instructions character varying,
    field jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.form_field OWNER TO postgres;

--
-- Name: form_notifications_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_notifications_notification (
    _order integer NOT NULL,
    _parent_id uuid NOT NULL,
    id character varying NOT NULL,
    email character varying NOT NULL,
    subject character varying NOT NULL,
    message jsonb NOT NULL
);


ALTER TABLE public.form_notifications_notification OWNER TO postgres;

--
-- Name: home; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying,
    meta_title character varying,
    meta_description character varying,
    meta_image_id uuid,
    _status public.enum_home_status DEFAULT 'draft'::public.enum_home_status,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone
);


ALTER TABLE public.home OWNER TO postgres;

--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alt character varying NOT NULL,
    quality numeric DEFAULT 80,
    optimise boolean DEFAULT true,
    resize_width numeric,
    resize_height numeric,
    fit public.enum_media_fit DEFAULT 'cover'::public.enum_media_fit,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    sizes_thumbnail_url character varying,
    sizes_thumbnail_width numeric,
    sizes_thumbnail_height numeric,
    sizes_thumbnail_mime_type character varying,
    sizes_thumbnail_filesize numeric,
    sizes_thumbnail_filename character varying,
    sizes_card_url character varying,
    sizes_card_width numeric,
    sizes_card_height numeric,
    sizes_card_mime_type character varying,
    sizes_card_filesize numeric,
    sizes_card_filename character varying,
    sizes_tablet_url character varying,
    sizes_tablet_width numeric,
    sizes_tablet_height numeric,
    sizes_tablet_mime_type character varying,
    sizes_tablet_filesize numeric,
    sizes_tablet_filename character varying
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    _order character varying,
    title character varying NOT NULL,
    type public.enum_menu_item_type DEFAULT 'url'::public.enum_menu_item_type,
    parent_id uuid,
    url character varying,
    custom character varying,
    passive character varying,
    depth numeric DEFAULT 0,
    handle character varying NOT NULL,
    reference_id character varying,
    value character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.menu_item OWNER TO postgres;

--
-- Name: menu_item_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id uuid NOT NULL,
    path character varying NOT NULL,
    pages_id uuid,
    posts_id uuid
);


ALTER TABLE public.menu_item_rels OWNER TO postgres;

--
-- Name: menu_item_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_item_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_item_rels_id_seq OWNER TO postgres;

--
-- Name: menu_item_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_item_rels_id_seq OWNED BY public.menu_item_rels.id;


--
-- Name: navigation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.navigation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying NOT NULL,
    generate_slug boolean DEFAULT true,
    slug character varying NOT NULL,
    handle character varying DEFAULT 'Qd7ka5xwUhxozjtut03rn'::character varying NOT NULL,
    data jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.navigation OWNER TO postgres;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    _order character varying,
    title character varying,
    meta_title character varying,
    meta_description character varying,
    meta_image_id uuid,
    generate_slug boolean DEFAULT true,
    slug character varying,
    author_id uuid,
    parent_id uuid,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_pages_status DEFAULT 'draft'::public.enum_pages_status
);


ALTER TABLE public.pages OWNER TO postgres;

--
-- Name: pages_breadcrumbs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pages_breadcrumbs (
    _order integer NOT NULL,
    _parent_id uuid NOT NULL,
    id character varying NOT NULL,
    doc_id uuid,
    url character varying,
    label character varying
);


ALTER TABLE public.pages_breadcrumbs OWNER TO postgres;

--
-- Name: payload_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    input jsonb,
    completed_at timestamp(3) with time zone,
    total_tried numeric DEFAULT 0,
    has_error boolean DEFAULT false,
    error jsonb,
    task_slug public.enum_payload_jobs_task_slug,
    queue character varying DEFAULT 'default'::character varying,
    wait_until timestamp(3) with time zone,
    processing boolean DEFAULT false,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_jobs OWNER TO postgres;

--
-- Name: payload_jobs_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_jobs_log (
    _order integer NOT NULL,
    _parent_id uuid NOT NULL,
    id character varying NOT NULL,
    executed_at timestamp(3) with time zone NOT NULL,
    completed_at timestamp(3) with time zone NOT NULL,
    task_slug public.enum_payload_jobs_log_task_slug NOT NULL,
    task_i_d character varying NOT NULL,
    input jsonb,
    output jsonb,
    state public.enum_payload_jobs_log_state NOT NULL,
    error jsonb
);


ALTER TABLE public.payload_jobs_log OWNER TO postgres;

--
-- Name: payload_kv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_kv (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.payload_kv OWNER TO postgres;

--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO postgres;

--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id uuid NOT NULL,
    path character varying NOT NULL,
    pages_id uuid,
    posts_id uuid,
    media_id uuid,
    users_id uuid,
    user_accounts_id uuid,
    user_sessions_id uuid,
    user_verifications_id uuid,
    navigation_id uuid,
    menu_item_id uuid,
    form_id uuid,
    form_field_id uuid,
    submissions_id uuid
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_migrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO postgres;

--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO postgres;

--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id uuid NOT NULL,
    path character varying NOT NULL,
    users_id uuid
);


ALTER TABLE public.payload_preferences_rels OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying,
    generate_slug boolean DEFAULT true,
    slug character varying,
    author_id uuid,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_posts_status DEFAULT 'draft'::public.enum_posts_status
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying NOT NULL,
    "from" character varying NOT NULL,
    form_id uuid,
    submission_data jsonb,
    csrf_token character varying,
    user_agent character varying,
    ip_address character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.submissions OWNER TO postgres;

--
-- Name: user_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id_id uuid NOT NULL,
    account_id character varying NOT NULL,
    provider_id character varying NOT NULL,
    access_token character varying,
    refresh_token character varying,
    access_token_expires_at timestamp(3) with time zone,
    refresh_token_expires_at timestamp(3) with time zone,
    scope character varying,
    id_token character varying,
    password character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_accounts OWNER TO postgres;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id_id uuid NOT NULL,
    token character varying NOT NULL,
    expires_at timestamp(3) with time zone NOT NULL,
    ip_address character varying,
    user_agent character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier character varying NOT NULL,
    value character varying NOT NULL,
    expires_at timestamp(3) with time zone NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_verifications OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying,
    image character varying,
    role character varying DEFAULT 'user'::character varying,
    email_verified boolean DEFAULT false,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_sessions (
    _order integer NOT NULL,
    _parent_id uuid NOT NULL,
    id character varying NOT NULL,
    created_at timestamp(3) with time zone,
    expires_at timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.users_sessions OWNER TO postgres;

--
-- Name: menu_item_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_rels ALTER COLUMN id SET DEFAULT nextval('public.menu_item_rels_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Data for Name: _home_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._home_v (id, version_title, version_meta_title, version_meta_description, version_meta_image_id, version__status, version_updated_at, version_created_at, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _pages_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._pages_v (id, parent_id, version__order, version_title, version_meta_title, version_meta_description, version_meta_image_id, version_generate_slug, version_slug, version_author_id, version_parent_id, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
81056176-41e6-4089-b81c-12fa997d1557	71f09702-8858-4a67-ba27-df362b60b353	a0	Page 1	\N	\N	\N	f	page-1	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:31.35+00	2026-01-23 22:42:24.156+00	published	2026-01-23 22:42:31.356+00	2026-01-23 22:42:31.356+00	t	f
00870890-5901-4379-8a34-9534c735ef62	71f09702-8858-4a67-ba27-df362b60b353	a0	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:24.157+00	2026-01-23 22:42:24.156+00	draft	2026-01-23 22:42:24.167+00	2026-01-23 22:42:24.167+00	f	f
b02a32e1-c642-4b66-ab1b-a810f829c783	71f09702-8858-4a67-ba27-df362b60b353	a0	Page 1	\N	\N	\N	t	page-1	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:28.587+00	2026-01-23 22:42:24.156+00	draft	2026-01-23 22:42:28.587+00	2026-01-23 22:42:28.587+00	f	t
83f2afeb-54f3-4ee8-aeb3-e890f26c4fe9	71f09702-8858-4a67-ba27-df362b60b353	a0	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:24.202+00	2026-01-23 22:42:24.156+00	draft	2026-01-23 22:42:24.202+00	2026-01-23 22:42:24.202+00	f	f
8a858e3d-701f-4f06-868d-7571fac3d088	5444c5da-2d4c-4585-98a5-0805f499088f	a1	Page 2	\N	\N	\N	f	page-2	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:49.015+00	2026-01-23 22:42:40.945+00	published	2026-01-23 22:42:49.024+00	2026-01-23 22:42:49.024+00	t	f
f76993f6-6dbf-471e-bf43-74acbf651866	5444c5da-2d4c-4585-98a5-0805f499088f	a1	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:40.945+00	2026-01-23 22:42:40.945+00	draft	2026-01-23 22:42:40.95+00	2026-01-23 22:42:40.95+00	f	f
f5ee4a6e-4a8a-4435-bf2c-ab3a9255dd5a	5444c5da-2d4c-4585-98a5-0805f499088f	a1	Page 2	\N	\N	\N	t	page-2	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:46.292+00	2026-01-23 22:42:40.945+00	draft	2026-01-23 22:42:46.292+00	2026-01-23 22:42:46.292+00	f	t
5e73b434-1461-41cf-a7e5-a600460c005f	5444c5da-2d4c-4585-98a5-0805f499088f	a1	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:40.989+00	2026-01-23 22:42:40.945+00	draft	2026-01-23 22:42:40.989+00	2026-01-23 22:42:40.989+00	f	f
2ea0ad56-b807-4b87-8740-829496d0f863	3b4dfe6a-da46-486e-9147-a71b9b72cf49	a0i	Page 1 Child 1	\N	\N	\N	f	page-1-child-1	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:26.399+00	2026-01-23 22:43:08.551+00	published	2026-01-23 22:43:26.403+00	2026-01-23 22:43:26.403+00	t	f
a9e9e56e-1964-4e47-939d-b0e1642e7779	3b4dfe6a-da46-486e-9147-a71b9b72cf49	a2	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:43:08.551+00	2026-01-23 22:43:08.551+00	draft	2026-01-23 22:43:08.557+00	2026-01-23 22:43:08.557+00	f	f
1fc6f5df-8f22-49f0-a64f-951d57338cf3	3b4dfe6a-da46-486e-9147-a71b9b72cf49	a2	\N	\N	\N	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:43:08.583+00	2026-01-23 22:43:08.551+00	draft	2026-01-23 22:43:08.583+00	2026-01-23 22:43:08.583+00	f	f
6314a924-94d6-4a9a-a72f-74f0dd92cd88	3b4dfe6a-da46-486e-9147-a71b9b72cf49	a2	Page 1 Child 1	\N	\N	\N	f	page-1-child-1	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:21.185+00	2026-01-23 22:43:08.551+00	published	2026-01-23 22:43:21.189+00	2026-01-23 22:43:21.189+00	f	f
99f61b40-8ad5-4848-a2f8-29e0728f13cc	3b4dfe6a-da46-486e-9147-a71b9b72cf49	a2	Page 1 Child 1	\N	\N	\N	f	page-1-child-1	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:19.851+00	2026-01-23 22:43:08.551+00	draft	2026-01-23 22:43:15.735+00	2026-01-23 22:43:19.851+00	f	t
1993ed8f-2b46-4349-9cb1-0337b4d9fbe5	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a0r	Page 1 Child 2	\N	\N	\N	f	page-1-child-2	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:58.754+00	2026-01-23 22:43:44.73+00	published	2026-01-23 22:43:58.759+00	2026-01-23 22:43:58.759+00	t	f
c01ef792-e401-4492-84dc-a81ff6acc6c5	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a2	Page 1 Child 2	\N	\N	\N	f	page-1-child-2	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:50.751+00	2026-01-23 22:43:44.73+00	published	2026-01-23 22:43:50.756+00	2026-01-23 22:43:50.756+00	f	f
87819b0d-5ca9-4d47-ab18-5f23645e420a	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a2	Page 1 Child 1	\N	\N	\N	f	page-1-child-1---copy	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:26.399+00	2026-01-23 22:43:44.73+00	draft	2026-01-23 22:43:44.734+00	2026-01-23 22:43:44.734+00	f	f
e774de2e-776e-4662-8b5e-900a2fd6f2d8	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a2	Page 1 Child 1	\N	\N	\N	f	page-1-child-1---copy	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:44.752+00	2026-01-23 22:43:44.73+00	draft	2026-01-23 22:43:44.752+00	2026-01-23 22:43:44.752+00	f	f
aa4455c6-fc2c-473d-a677-f4cf52df2451	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a2	Page 1 Child 2	\N	\N	\N	f	page-1-child-1---copy	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:48.616+00	2026-01-23 22:43:44.73+00	draft	2026-01-23 22:43:48.616+00	2026-01-23 22:43:48.616+00	f	t
12f120e3-24fc-404c-81cb-65b581d827b8	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a0r	Page 1 Child 2	\N	\N	\N	f	page-1-child-2	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:55.331+00	2026-01-23 22:43:44.73+00	draft	2026-01-23 22:43:55.334+00	2026-01-23 22:43:55.334+00	f	f
10eed6c2-64a3-45ad-927a-464ad0a38e62	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a2	Page 1 Child 2	\N	\N	\N	f	page-1-child-2	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:50.862+00	2026-01-23 22:43:44.73+00	draft	2026-01-23 22:43:50.862+00	2026-01-23 22:43:50.862+00	f	t
\.


--
-- Data for Name: _pages_v_version_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._pages_v_version_breadcrumbs (_order, _parent_id, id, doc_id, url, label, _uuid) FROM stdin;
1	00870890-5901-4379-8a34-9534c735ef62	13397d70-5625-4eb5-936e-fb5e632d7172	\N	/undefined	Untitled	6973f95000019be573eb175b
1	83f2afeb-54f3-4ee8-aeb3-e890f26c4fe9	baca6344-7409-49dd-a898-b75ccd68ddc7	71f09702-8858-4a67-ba27-df362b60b353	/null	Untitled	6973f95000019be573eb175b
1	b02a32e1-c642-4b66-ab1b-a810f829c783	41d164e2-9b1f-4559-ac73-35411129d2fd	71f09702-8858-4a67-ba27-df362b60b353	/null	Page 1	6973f95000019be573eb175b
1	81056176-41e6-4089-b81c-12fa997d1557	abb1c8ac-6cb1-4d98-aa09-2459e2f05193	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f95000019be573eb175b
1	f76993f6-6dbf-471e-bf43-74acbf651866	5d2f21be-8c7d-4690-883a-c0a677ac4e00	\N	/undefined	Untitled	6973f96000019be573eb175c
1	5e73b434-1461-41cf-a7e5-a600460c005f	40251368-d8e5-46ca-9d04-007228f19b4f	5444c5da-2d4c-4585-98a5-0805f499088f	/null	Untitled	6973f96000019be573eb175c
1	f5ee4a6e-4a8a-4435-bf2c-ab3a9255dd5a	ea71f627-3ebf-41fb-8ed4-65be238e0827	5444c5da-2d4c-4585-98a5-0805f499088f	/null	Page 2	6973f96000019be573eb175c
1	8a858e3d-701f-4f06-868d-7571fac3d088	215b5a29-6e6c-4b47-a92b-77714983e2df	5444c5da-2d4c-4585-98a5-0805f499088f	/page-2	Page 2	6973f96000019be573eb175c
1	a9e9e56e-1964-4e47-939d-b0e1642e7779	76fa8cce-f7c5-404c-b29c-ac8ec8256356	\N	/undefined	Untitled	6973f97c00019be573eb175d
1	1fc6f5df-8f22-49f0-a64f-951d57338cf3	d70aaf5c-6c65-488d-b97c-c0f56b71f2eb	3b4dfe6a-da46-486e-9147-a71b9b72cf49	/null	Untitled	6973f97c00019be573eb175d
1	99f61b40-8ad5-4848-a2f8-29e0728f13cc	03682fa0-036f-48e3-8d12-b49f1c1766fc	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f97c00019be573eb175d
2	99f61b40-8ad5-4848-a2f8-29e0728f13cc	6b8a308f-356e-4ee3-9d93-f3fa779fe086	3b4dfe6a-da46-486e-9147-a71b9b72cf49	/page-1/page-1-child-1	Page 1 Child 1	6973f98700019be573eb175e
1	6314a924-94d6-4a9a-a72f-74f0dd92cd88	50c7e856-df02-4b44-a199-c68cff04c62c	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f97c00019be573eb175d
2	6314a924-94d6-4a9a-a72f-74f0dd92cd88	f7bdacc8-7eed-4cb5-a6b1-2117a00876d3	3b4dfe6a-da46-486e-9147-a71b9b72cf49	/page-1/page-1-child-1	Page 1 Child 1	6973f98700019be573eb175e
1	2ea0ad56-b807-4b87-8740-829496d0f863	308fc765-9343-4aeb-813e-eeb57384b47b	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f97c00019be573eb175d
2	2ea0ad56-b807-4b87-8740-829496d0f863	e1376467-6ae2-48aa-8799-2b7d23beb8a9	3b4dfe6a-da46-486e-9147-a71b9b72cf49	/page-1/page-1-child-1	Page 1 Child 1	6973f98700019be573eb175e
1	87819b0d-5ca9-4d47-ab18-5f23645e420a	00d67861-8a20-4e8f-b2dc-ee4e5efce8c5	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	87819b0d-5ca9-4d47-ab18-5f23645e420a	df76e540-fe79-45bc-a735-498c378a5070	\N	/page-1/page-1-child-1 - Copy	Page 1 Child 1	6973f9a000019be573eb1760
1	e774de2e-776e-4662-8b5e-900a2fd6f2d8	c63a9100-5c77-4cf9-a242-799f8360c56d	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	e774de2e-776e-4662-8b5e-900a2fd6f2d8	e569f047-30e4-4671-88f5-604ac25c3a56	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-1---copy	Page 1 Child 1	6973f9a000019be573eb1760
1	aa4455c6-fc2c-473d-a677-f4cf52df2451	fd0caae8-de61-491d-ade9-af12a730e47d	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	aa4455c6-fc2c-473d-a677-f4cf52df2451	67e70a4d-2a7d-4ee6-a038-e2e3444eac18	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-1---copy	Page 1 Child 2	6973f9a000019be573eb1760
1	c01ef792-e401-4492-84dc-a81ff6acc6c5	f537e852-eccc-4b62-82ba-4d9fa2e8032c	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	c01ef792-e401-4492-84dc-a81ff6acc6c5	d630b08f-fc2f-4bbe-a99c-37309ca9bd3b	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-2	Page 1 Child 2	6973f9a000019be573eb1760
1	10eed6c2-64a3-45ad-927a-464ad0a38e62	5bac6d6d-3b0a-44e7-8da7-277dd902d1b3	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	10eed6c2-64a3-45ad-927a-464ad0a38e62	ee37ec16-de44-4df1-a643-b16e032d58e3	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-2	Page 1 Child 2	6973f9a000019be573eb1760
1	12f120e3-24fc-404c-81cb-65b581d827b8	fd393720-7d15-4cd0-8017-b0c5f2bddc6e	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	12f120e3-24fc-404c-81cb-65b581d827b8	73745cca-1f6f-41e8-ab60-73e4c8e2b44f	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-2	Page 1 Child 2	6973f9a000019be573eb1760
1	1993ed8f-2b46-4349-9cb1-0337b4d9fbe5	5f855bef-9ae1-4eed-8282-1657aa069112	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1	6973f9a000019be573eb175f
2	1993ed8f-2b46-4349-9cb1-0337b4d9fbe5	76f8bd16-05b1-437c-a057-89182d5ca60e	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-2	Page 1 Child 2	6973f9a000019be573eb1760
\.


--
-- Data for Name: _posts_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._posts_v (id, parent_id, version_title, version_generate_slug, version_slug, version_author_id, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
782ba30e-97aa-44e0-87b2-5f0bd4399c74	a489bd83-9700-4b51-8880-5f4def115c87	Hello world	f	hello-world	186f4563-340b-48e0-8598-f7930a759cc7	2026-01-23 22:44:27.135+00	2026-01-23 22:44:16.595+00	published	2026-01-23 22:44:27.141+00	2026-01-23 22:44:27.141+00	t	f
64740d77-0bcd-4487-8008-44c43065f906	a489bd83-9700-4b51-8880-5f4def115c87	Hello world	t	hello-world	186f4563-340b-48e0-8598-f7930a759cc7	2026-01-23 22:44:26.204+00	2026-01-23 22:44:16.595+00	draft	2026-01-23 22:44:26.204+00	2026-01-23 22:44:26.204+00	f	t
5090cd2a-d4cb-4beb-b5af-8a7713934055	a489bd83-9700-4b51-8880-5f4def115c87	\N	t	\N	186f4563-340b-48e0-8598-f7930a759cc7	2026-01-23 22:44:16.595+00	2026-01-23 22:44:16.595+00	draft	2026-01-23 22:44:16.599+00	2026-01-23 22:44:16.599+00	f	f
\.


--
-- Data for Name: form; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form (id, title, generate_slug, slug, form_submit_button_label, submission_confirmation_type, submission_confirmation_message, submission_redirect_url, handle, pages, form_data, form_schema, updated_at, created_at) FROM stdin;
0e01eee1-1ff7-4527-ac11-b7722cc5a982	Contact form	f	contact-form	Submit	\N	\N	\N	xRE8Cg50a8jA1gE8LkjuY	[{"id": "qWMvk-qigRUVnLs0tf5al", "rows": [{"id": "feKUopC2KTW3s8UqzR2xk"}], "title": "Page 1", "backButton": "Back", "nextButton": "Next"}]	\N	\N	2026-01-23 22:44:44.697+00	2026-01-23 22:44:44.697+00
\.


--
-- Data for Name: form_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_field (id, title, handle, page_id, row_index, column_index, type, name, label, error_message, instructions, field, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: form_notifications_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_notifications_notification (_order, _parent_id, id, email, subject, message) FROM stdin;
\.


--
-- Data for Name: home; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home (id, title, meta_title, meta_description, meta_image_id, _status, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, alt, quality, optimise, resize_width, resize_height, fit, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumbnail_url, sizes_thumbnail_width, sizes_thumbnail_height, sizes_thumbnail_mime_type, sizes_thumbnail_filesize, sizes_thumbnail_filename, sizes_card_url, sizes_card_width, sizes_card_height, sizes_card_mime_type, sizes_card_filesize, sizes_card_filename, sizes_tablet_url, sizes_tablet_width, sizes_tablet_height, sizes_tablet_mime_type, sizes_tablet_filesize, sizes_tablet_filename) FROM stdin;
\.


--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item (id, _order, title, type, parent_id, url, custom, passive, depth, handle, reference_id, value, updated_at, created_at) FROM stdin;
f2eee138-b0c1-4b52-a866-7ce451526736	a0	Home	custom	\N	\N	/	\N	0	By0LblnZgfOSmK1tkpQqx	\N	/	2026-01-23 22:39:28.768+00	2026-01-23 22:39:28.768+00
fe7cece8-e0b3-4474-b74b-a90a6ec3f70d	a1	Made up	custom	\N	\N	#made-up	\N	0	By0LblnZgfOSmK1tkpQqx	\N	#made-up	2026-01-23 22:39:39.528+00	2026-01-23 22:39:39.528+00
8f821d6a-8a12-4be1-a610-0f8cbc936e02	a2	Wibble Family	url	\N	https://www.spon.cloud	\N	\N	0	By0LblnZgfOSmK1tkpQqx	\N	https://www.spon.cloud	2026-01-23 22:40:04.441+00	2026-01-23 22:40:04.441+00
00a8ca6b-2ff3-401a-9ab3-3e16f093261b	a3	My Wibble	passive	8f821d6a-8a12-4be1-a610-0f8cbc936e02	\N	\N	Wibble Elders	1	By0LblnZgfOSmK1tkpQqx	\N	Wibble Elders	2026-01-23 22:40:20.809+00	2026-01-23 22:40:20.809+00
f48c3494-778e-4802-a73c-bd3fecdf9e27	a4	Pappa	custom	00a8ca6b-2ff3-401a-9ab3-3e16f093261b	\N	#wa	\N	2	By0LblnZgfOSmK1tkpQqx	\N	#wa	2026-01-23 22:40:43.807+00	2026-01-23 22:40:43.807+00
3a6820f0-f941-41f7-bf30-7ce96ce5f023	a5	Mumma	custom	00a8ca6b-2ff3-401a-9ab3-3e16f093261b	\N	#1	\N	2	By0LblnZgfOSmK1tkpQqx	\N	#1	2026-01-23 22:40:56.508+00	2026-01-23 22:40:56.508+00
38c3724d-5da9-48b7-94c6-42b1166e08ca	a6	Wibble Kids	passive	8f821d6a-8a12-4be1-a610-0f8cbc936e02	\N	\N	Wibble Shits	1	By0LblnZgfOSmK1tkpQqx	\N	Wibble Shits	2026-01-23 22:41:26.86+00	2026-01-23 22:41:26.86+00
70ca703c-19ed-4b85-a00d-7dcadce8d5e7	a7	Shit 1	custom	38c3724d-5da9-48b7-94c6-42b1166e08ca	\N	#anus	\N	2	By0LblnZgfOSmK1tkpQqx	\N	#anus	2026-01-23 22:41:44.591+00	2026-01-23 22:41:44.59+00
\.


--
-- Data for Name: menu_item_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item_rels (id, "order", parent_id, path, pages_id, posts_id) FROM stdin;
\.


--
-- Data for Name: navigation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.navigation (id, title, generate_slug, slug, handle, data, updated_at, created_at) FROM stdin;
6b29cdb3-edee-4036-a03c-800f7ec41053	Main menu	f	main-menu	By0LblnZgfOSmK1tkpQqx	[{"id": "f2eee138-b0c1-4b52-a866-7ce451526736", "type": "custom", "depth": 0, "title": "Home", "value": "/", "parent": null}, {"id": "fe7cece8-e0b3-4474-b74b-a90a6ec3f70d", "type": "custom", "depth": 0, "title": "Made up", "value": "#made-up", "parent": null}, {"id": "8f821d6a-8a12-4be1-a610-0f8cbc936e02", "type": "url", "depth": 0, "title": "Wibble Family", "value": "https://www.spon.cloud", "parent": null, "children": [{"id": "00a8ca6b-2ff3-401a-9ab3-3e16f093261b", "type": "passive", "depth": 1, "title": "My Wibble", "value": "Wibble Elders", "parent": "8f821d6a-8a12-4be1-a610-0f8cbc936e02", "children": [{"id": "f48c3494-778e-4802-a73c-bd3fecdf9e27", "type": "custom", "depth": 2, "title": "Pappa", "value": "#wa", "parent": "00a8ca6b-2ff3-401a-9ab3-3e16f093261b"}, {"id": "3a6820f0-f941-41f7-bf30-7ce96ce5f023", "type": "custom", "depth": 2, "title": "Mumma", "value": "#1", "parent": "00a8ca6b-2ff3-401a-9ab3-3e16f093261b"}]}, {"id": "38c3724d-5da9-48b7-94c6-42b1166e08ca", "type": "passive", "depth": 1, "title": "Wibble Kids", "value": "Wibble Shits", "parent": "8f821d6a-8a12-4be1-a610-0f8cbc936e02", "children": [{"id": "70ca703c-19ed-4b85-a00d-7dcadce8d5e7", "type": "custom", "depth": 2, "title": "Shit 1", "value": "#anus", "parent": "38c3724d-5da9-48b7-94c6-42b1166e08ca"}]}]}]	2026-01-23 22:41:50.901+00	2026-01-23 22:39:42.774+00
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pages (id, _order, title, meta_title, meta_description, meta_image_id, generate_slug, slug, author_id, parent_id, updated_at, created_at, _status) FROM stdin;
71f09702-8858-4a67-ba27-df362b60b353	a0	Page 1	\N	\N	\N	f	page-1	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:31.35+00	2026-01-23 22:42:24.156+00	published
5444c5da-2d4c-4585-98a5-0805f499088f	a1	Page 2	\N	\N	\N	f	page-2	186f4563-340b-48e0-8598-f7930a759cc7	\N	2026-01-23 22:42:49.015+00	2026-01-23 22:42:40.945+00	published
3b4dfe6a-da46-486e-9147-a71b9b72cf49	a0i	Page 1 Child 1	\N	\N	\N	f	page-1-child-1	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:26.399+00	2026-01-23 22:43:08.551+00	published
f0794a1f-7ce6-45c2-8976-aa5f6d97d091	a0r	Page 1 Child 2	\N	\N	\N	f	page-1-child-2	186f4563-340b-48e0-8598-f7930a759cc7	71f09702-8858-4a67-ba27-df362b60b353	2026-01-23 22:43:58.754+00	2026-01-23 22:43:44.73+00	published
\.


--
-- Data for Name: pages_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pages_breadcrumbs (_order, _parent_id, id, doc_id, url, label) FROM stdin;
1	71f09702-8858-4a67-ba27-df362b60b353	6973f95000019be573eb175b	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1
1	5444c5da-2d4c-4585-98a5-0805f499088f	6973f96000019be573eb175c	5444c5da-2d4c-4585-98a5-0805f499088f	/page-2	Page 2
1	3b4dfe6a-da46-486e-9147-a71b9b72cf49	6973f97c00019be573eb175d	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1
2	3b4dfe6a-da46-486e-9147-a71b9b72cf49	6973f98700019be573eb175e	3b4dfe6a-da46-486e-9147-a71b9b72cf49	/page-1/page-1-child-1	Page 1 Child 1
1	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	6973f9a000019be573eb175f	71f09702-8858-4a67-ba27-df362b60b353	/page-1	Page 1
2	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	6973f9a000019be573eb1760	f0794a1f-7ce6-45c2-8976-aa5f6d97d091	/page-1/page-1-child-2	Page 1 Child 2
\.


--
-- Data for Name: payload_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_jobs (id, input, completed_at, total_tried, has_error, error, task_slug, queue, wait_until, processing, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_jobs_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_jobs_log (_order, _parent_id, id, executed_at, completed_at, task_slug, task_i_d, input, output, state, error) FROM stdin;
\.


--
-- Data for Name: payload_kv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_kv (id, key, data) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, pages_id, posts_id, media_id, users_id, user_accounts_id, user_sessions_id, user_verifications_id, navigation_id, menu_item_id, form_id, form_field_id, submissions_id) FROM stdin;
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
fb6a60f5-5db4-495f-86a1-064e2c06be39	20260123_223135	1	2026-01-23 22:36:51.726+00	2026-01-23 22:36:51.724+00
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
286f8da0-7b46-4760-92fb-a355563b95c6	collection-navigation	{"editViewType": "default"}	2026-01-23 22:39:15.143+00	2026-01-23 22:39:13.526+00
013bc213-d6a0-418c-b8e4-0db014cf21eb	collection-form	{"editViewType": "default"}	2026-01-23 22:42:20.367+00	2026-01-23 22:39:09.035+00
6d1643d9-86a7-4a15-889e-4857f941c366	collection-pages	{"sort": "_order", "limit": 10, "editViewType": "default"}	2026-01-23 22:42:58.623+00	2026-01-23 22:42:21.745+00
64b154ea-5d62-41eb-8e7e-7056827740be	collection-posts	{"editViewType": "default"}	2026-01-23 22:44:16.869+00	2026-01-23 22:44:15.426+00
3fcbecea-93e9-401f-9125-e59a790fb3fb	collection-form_field	{}	2026-01-23 22:44:30.869+00	2026-01-23 22:44:30.869+00
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id) FROM stdin;
3	\N	286f8da0-7b46-4760-92fb-a355563b95c6	user	186f4563-340b-48e0-8598-f7930a759cc7
4	\N	013bc213-d6a0-418c-b8e4-0db014cf21eb	user	186f4563-340b-48e0-8598-f7930a759cc7
7	\N	6d1643d9-86a7-4a15-889e-4857f941c366	user	186f4563-340b-48e0-8598-f7930a759cc7
9	\N	64b154ea-5d62-41eb-8e7e-7056827740be	user	186f4563-340b-48e0-8598-f7930a759cc7
10	\N	3fcbecea-93e9-401f-9125-e59a790fb3fb	user	186f4563-340b-48e0-8598-f7930a759cc7
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, title, generate_slug, slug, author_id, updated_at, created_at, _status) FROM stdin;
a489bd83-9700-4b51-8880-5f4def115c87	Hello world	f	hello-world	186f4563-340b-48e0-8598-f7930a759cc7	2026-01-23 22:44:27.135+00	2026-01-23 22:44:16.595+00	published
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.submissions (id, title, "from", form_id, submission_data, csrf_token, user_agent, ip_address, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_accounts (id, user_id_id, account_id, provider_id, access_token, refresh_token, access_token_expires_at, refresh_token_expires_at, scope, id_token, password, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id_id, token, expires_at, ip_address, user_agent, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_verifications (id, identifier, value, expires_at, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, image, role, email_verified, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until) FROM stdin;
186f4563-340b-48e0-8598-f7930a759cc7	admin	\N	admin	t	2026-01-23 22:38:39.982+00	2026-01-23 22:38:39.981+00	hello@spon.io	\N	\N	d7e85961d5b753a98820e92b0a63b68145f011e9f208688b5b27a90d13cd222f	eb1fc7c6271bf37885eff38abd84c88fac01c25767c0a07d2be862be532e2066da45a08c946179813960bcee6ce07616db61cf8776d6a655785c18ed0af79c4ddf6cf5ffd990407cfa811412ff7097236561ff2f8f35e284437985eb1c105a37bba2434738d856f59c62d891f01b2cd9f579f66e71fa791843ca76991618f391bfb1c950022c7c22e3182d0daebc2169353c05b4fc87eee8209167611b0492ec3fa6afb53682feee62b853cb6709c9124533720e4adcc8aa4990d2ba10773472cc459aceeeecc513f97d23f4888d60d811324051a2308412efab0df79e27184e70792d9b04814fe14a331d3d28efd21c239a20d3364c130c0987da4e752cd7baa0d0791cf29918f6059e0b3cf8cf878679b3b671496fc7f5e1f44efa76f9603c591b73b99422eb278584c3d7492cedf2a1afa86e9f2c3e5e55fc1234d114b9da352d64bfe67b8ee314d26399a5c0a376067ed62846325479525d7c1aba1b828f0181b3875877265c19a1c15fb3bb0eb82da53a1f8e9610b1ba78494335493eda3070ad9638695d2030aa4819ac6bf43348fead201d281acf9f8d19bc8fec937912b4aacc9f02f0216b70002a32270b931cb95e714ac476cc5ffce0800ab339a71b21a8c03b099b63e9938154133c326bdead2f7a3b81ed3eab93618c3464f6bfe97e2970cf1dc5a09c774facfdecb6b0df7990dc19d107f3ec3b2261d26c57f6	0	\N
\.


--
-- Data for Name: users_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_sessions (_order, _parent_id, id, created_at, expires_at) FROM stdin;
1	186f4563-340b-48e0-8598-f7930a759cc7	1d60d0e5-47ec-41ed-9d17-eb02a82943b2	2026-01-23 22:38:40.074+00	2026-01-24 00:38:40.074+00
\.


--
-- Name: menu_item_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_item_rels_id_seq', 1, false);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 16, true);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 10, true);


--
-- Name: _home_v _home_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._home_v
    ADD CONSTRAINT _home_v_pkey PRIMARY KEY (id);


--
-- Name: _pages_v _pages_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v
    ADD CONSTRAINT _pages_v_pkey PRIMARY KEY (id);


--
-- Name: _pages_v_version_breadcrumbs _pages_v_version_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v_version_breadcrumbs
    ADD CONSTRAINT _pages_v_version_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: _posts_v _posts_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_pkey PRIMARY KEY (id);


--
-- Name: form_field form_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_field
    ADD CONSTRAINT form_field_pkey PRIMARY KEY (id);


--
-- Name: form_notifications_notification form_notifications_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_notifications_notification
    ADD CONSTRAINT form_notifications_notification_pkey PRIMARY KEY (id);


--
-- Name: form form_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_pkey PRIMARY KEY (id);


--
-- Name: home home_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT home_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (id);


--
-- Name: menu_item_rels menu_item_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_rels
    ADD CONSTRAINT menu_item_rels_pkey PRIMARY KEY (id);


--
-- Name: navigation navigation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.navigation
    ADD CONSTRAINT navigation_pkey PRIMARY KEY (id);


--
-- Name: pages_breadcrumbs pages_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages_breadcrumbs
    ADD CONSTRAINT pages_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: payload_jobs_log payload_jobs_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_jobs_log
    ADD CONSTRAINT payload_jobs_log_pkey PRIMARY KEY (id);


--
-- Name: payload_jobs payload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_jobs
    ADD CONSTRAINT payload_jobs_pkey PRIMARY KEY (id);


--
-- Name: payload_kv payload_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_kv
    ADD CONSTRAINT payload_kv_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: user_accounts user_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_verifications user_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_verifications
    ADD CONSTRAINT user_verifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_sessions users_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_pkey PRIMARY KEY (id);


--
-- Name: _home_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_autosave_idx ON public._home_v USING btree (autosave);


--
-- Name: _home_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_created_at_idx ON public._home_v USING btree (created_at);


--
-- Name: _home_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_latest_idx ON public._home_v USING btree (latest);


--
-- Name: _home_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_updated_at_idx ON public._home_v USING btree (updated_at);


--
-- Name: _home_v_version_meta_version_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_version_meta_version_meta_image_idx ON public._home_v USING btree (version_meta_image_id);


--
-- Name: _home_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_v_version_version__status_idx ON public._home_v USING btree (version__status);


--
-- Name: _pages_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_autosave_idx ON public._pages_v USING btree (autosave);


--
-- Name: _pages_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_created_at_idx ON public._pages_v USING btree (created_at);


--
-- Name: _pages_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_latest_idx ON public._pages_v USING btree (latest);


--
-- Name: _pages_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_parent_idx ON public._pages_v USING btree (parent_id);


--
-- Name: _pages_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_updated_at_idx ON public._pages_v USING btree (updated_at);


--
-- Name: _pages_v_version_breadcrumbs_doc_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_breadcrumbs_doc_idx ON public._pages_v_version_breadcrumbs USING btree (doc_id);


--
-- Name: _pages_v_version_breadcrumbs_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_breadcrumbs_order_idx ON public._pages_v_version_breadcrumbs USING btree (_order);


--
-- Name: _pages_v_version_breadcrumbs_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_breadcrumbs_parent_id_idx ON public._pages_v_version_breadcrumbs USING btree (_parent_id);


--
-- Name: _pages_v_version_meta_version_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_meta_version_meta_image_idx ON public._pages_v USING btree (version_meta_image_id);


--
-- Name: _pages_v_version_version__order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version__order_idx ON public._pages_v USING btree (version__order);


--
-- Name: _pages_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version__status_idx ON public._pages_v USING btree (version__status);


--
-- Name: _pages_v_version_version_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version_author_idx ON public._pages_v USING btree (version_author_id);


--
-- Name: _pages_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version_created_at_idx ON public._pages_v USING btree (version_created_at);


--
-- Name: _pages_v_version_version_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version_parent_idx ON public._pages_v USING btree (version_parent_id);


--
-- Name: _pages_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version_slug_idx ON public._pages_v USING btree (version_slug);


--
-- Name: _pages_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _pages_v_version_version_updated_at_idx ON public._pages_v USING btree (version_updated_at);


--
-- Name: _posts_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_autosave_idx ON public._posts_v USING btree (autosave);


--
-- Name: _posts_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_created_at_idx ON public._posts_v USING btree (created_at);


--
-- Name: _posts_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_latest_idx ON public._posts_v USING btree (latest);


--
-- Name: _posts_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_parent_idx ON public._posts_v USING btree (parent_id);


--
-- Name: _posts_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_updated_at_idx ON public._posts_v USING btree (updated_at);


--
-- Name: _posts_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_version_version__status_idx ON public._posts_v USING btree (version__status);


--
-- Name: _posts_v_version_version_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_version_version_author_idx ON public._posts_v USING btree (version_author_id);


--
-- Name: _posts_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_version_version_created_at_idx ON public._posts_v USING btree (version_created_at);


--
-- Name: _posts_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_version_version_slug_idx ON public._posts_v USING btree (version_slug);


--
-- Name: _posts_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _posts_v_version_version_updated_at_idx ON public._posts_v USING btree (version_updated_at);


--
-- Name: form_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_created_at_idx ON public.form USING btree (created_at);


--
-- Name: form_field_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_field_created_at_idx ON public.form_field USING btree (created_at);


--
-- Name: form_field_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_field_updated_at_idx ON public.form_field USING btree (updated_at);


--
-- Name: form_notifications_notification_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_notifications_notification_order_idx ON public.form_notifications_notification USING btree (_order);


--
-- Name: form_notifications_notification_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_notifications_notification_parent_id_idx ON public.form_notifications_notification USING btree (_parent_id);


--
-- Name: form_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX form_slug_idx ON public.form USING btree (slug);


--
-- Name: form_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_updated_at_idx ON public.form USING btree (updated_at);


--
-- Name: home__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home__status_idx ON public.home USING btree (_status);


--
-- Name: home_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_meta_meta_image_idx ON public.home USING btree (meta_image_id);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_sizes_card_sizes_card_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_card_sizes_card_filename_idx ON public.media USING btree (sizes_card_filename);


--
-- Name: media_sizes_tablet_sizes_tablet_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_tablet_sizes_tablet_filename_idx ON public.media USING btree (sizes_tablet_filename);


--
-- Name: media_sizes_thumbnail_sizes_thumbnail_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_thumbnail_sizes_thumbnail_filename_idx ON public.media USING btree (sizes_thumbnail_filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: menu_item__order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item__order_idx ON public.menu_item USING btree (_order);


--
-- Name: menu_item_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_created_at_idx ON public.menu_item USING btree (created_at);


--
-- Name: menu_item_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_parent_idx ON public.menu_item USING btree (parent_id);


--
-- Name: menu_item_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_rels_order_idx ON public.menu_item_rels USING btree ("order");


--
-- Name: menu_item_rels_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_rels_pages_id_idx ON public.menu_item_rels USING btree (pages_id);


--
-- Name: menu_item_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_rels_parent_idx ON public.menu_item_rels USING btree (parent_id);


--
-- Name: menu_item_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_rels_path_idx ON public.menu_item_rels USING btree (path);


--
-- Name: menu_item_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_rels_posts_id_idx ON public.menu_item_rels USING btree (posts_id);


--
-- Name: menu_item_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_updated_at_idx ON public.menu_item USING btree (updated_at);


--
-- Name: navigation_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX navigation_created_at_idx ON public.navigation USING btree (created_at);


--
-- Name: navigation_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX navigation_slug_idx ON public.navigation USING btree (slug);


--
-- Name: navigation_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX navigation_updated_at_idx ON public.navigation USING btree (updated_at);


--
-- Name: pages__order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages__order_idx ON public.pages USING btree (_order);


--
-- Name: pages__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages__status_idx ON public.pages USING btree (_status);


--
-- Name: pages_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_author_idx ON public.pages USING btree (author_id);


--
-- Name: pages_breadcrumbs_doc_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_breadcrumbs_doc_idx ON public.pages_breadcrumbs USING btree (doc_id);


--
-- Name: pages_breadcrumbs_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_breadcrumbs_order_idx ON public.pages_breadcrumbs USING btree (_order);


--
-- Name: pages_breadcrumbs_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_breadcrumbs_parent_id_idx ON public.pages_breadcrumbs USING btree (_parent_id);


--
-- Name: pages_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_created_at_idx ON public.pages USING btree (created_at);


--
-- Name: pages_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_meta_meta_image_idx ON public.pages USING btree (meta_image_id);


--
-- Name: pages_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_parent_idx ON public.pages USING btree (parent_id);


--
-- Name: pages_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX pages_slug_idx ON public.pages USING btree (slug);


--
-- Name: pages_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_updated_at_idx ON public.pages USING btree (updated_at);


--
-- Name: payload_jobs_completed_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_completed_at_idx ON public.payload_jobs USING btree (completed_at);


--
-- Name: payload_jobs_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_created_at_idx ON public.payload_jobs USING btree (created_at);


--
-- Name: payload_jobs_has_error_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_has_error_idx ON public.payload_jobs USING btree (has_error);


--
-- Name: payload_jobs_log_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_log_order_idx ON public.payload_jobs_log USING btree (_order);


--
-- Name: payload_jobs_log_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_log_parent_id_idx ON public.payload_jobs_log USING btree (_parent_id);


--
-- Name: payload_jobs_processing_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_processing_idx ON public.payload_jobs USING btree (processing);


--
-- Name: payload_jobs_queue_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_queue_idx ON public.payload_jobs USING btree (queue);


--
-- Name: payload_jobs_task_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_task_slug_idx ON public.payload_jobs USING btree (task_slug);


--
-- Name: payload_jobs_total_tried_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_total_tried_idx ON public.payload_jobs USING btree (total_tried);


--
-- Name: payload_jobs_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_updated_at_idx ON public.payload_jobs USING btree (updated_at);


--
-- Name: payload_jobs_wait_until_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_jobs_wait_until_idx ON public.payload_jobs USING btree (wait_until);


--
-- Name: payload_kv_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX payload_kv_key_idx ON public.payload_kv USING btree (key);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_form_field_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_form_field_id_idx ON public.payload_locked_documents_rels USING btree (form_field_id);


--
-- Name: payload_locked_documents_rels_form_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_form_id_idx ON public.payload_locked_documents_rels USING btree (form_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_menu_item_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_menu_item_id_idx ON public.payload_locked_documents_rels USING btree (menu_item_id);


--
-- Name: payload_locked_documents_rels_navigation_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_navigation_id_idx ON public.payload_locked_documents_rels USING btree (navigation_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_pages_id_idx ON public.payload_locked_documents_rels USING btree (pages_id);


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_posts_id_idx ON public.payload_locked_documents_rels USING btree (posts_id);


--
-- Name: payload_locked_documents_rels_submissions_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_submissions_id_idx ON public.payload_locked_documents_rels USING btree (submissions_id);


--
-- Name: payload_locked_documents_rels_user_accounts_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_user_accounts_id_idx ON public.payload_locked_documents_rels USING btree (user_accounts_id);


--
-- Name: payload_locked_documents_rels_user_sessions_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_user_sessions_id_idx ON public.payload_locked_documents_rels USING btree (user_sessions_id);


--
-- Name: payload_locked_documents_rels_user_verifications_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_user_verifications_id_idx ON public.payload_locked_documents_rels USING btree (user_verifications_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: posts__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX posts__status_idx ON public.posts USING btree (_status);


--
-- Name: posts_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX posts_author_idx ON public.posts USING btree (author_id);


--
-- Name: posts_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX posts_created_at_idx ON public.posts USING btree (created_at);


--
-- Name: posts_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX posts_slug_idx ON public.posts USING btree (slug);


--
-- Name: posts_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX posts_updated_at_idx ON public.posts USING btree (updated_at);


--
-- Name: submissions_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submissions_created_at_idx ON public.submissions USING btree (created_at);


--
-- Name: submissions_form_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submissions_form_idx ON public.submissions USING btree (form_id);


--
-- Name: submissions_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submissions_updated_at_idx ON public.submissions USING btree (updated_at);


--
-- Name: user_accounts_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_accounts_created_at_idx ON public.user_accounts USING btree (created_at);


--
-- Name: user_accounts_provider_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_accounts_provider_id_idx ON public.user_accounts USING btree (provider_id);


--
-- Name: user_accounts_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_accounts_updated_at_idx ON public.user_accounts USING btree (updated_at);


--
-- Name: user_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_accounts_user_id_idx ON public.user_accounts USING btree (user_id_id);


--
-- Name: user_sessions_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_created_at_idx ON public.user_sessions USING btree (created_at);


--
-- Name: user_sessions_ip_address_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_ip_address_idx ON public.user_sessions USING btree (ip_address);


--
-- Name: user_sessions_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_sessions_token_idx ON public.user_sessions USING btree (token);


--
-- Name: user_sessions_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_updated_at_idx ON public.user_sessions USING btree (updated_at);


--
-- Name: user_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_user_id_idx ON public.user_sessions USING btree (user_id_id);


--
-- Name: user_verifications_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_verifications_created_at_idx ON public.user_verifications USING btree (created_at);


--
-- Name: user_verifications_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_verifications_updated_at_idx ON public.user_verifications USING btree (updated_at);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_sessions_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_sessions_order_idx ON public.users_sessions USING btree (_order);


--
-- Name: users_sessions_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_sessions_parent_id_idx ON public.users_sessions USING btree (_parent_id);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: _home_v _home_v_version_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._home_v
    ADD CONSTRAINT _home_v_version_meta_image_id_media_id_fk FOREIGN KEY (version_meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _pages_v _pages_v_parent_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v
    ADD CONSTRAINT _pages_v_parent_id_pages_id_fk FOREIGN KEY (parent_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _pages_v _pages_v_version_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v
    ADD CONSTRAINT _pages_v_version_author_id_users_id_fk FOREIGN KEY (version_author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: _pages_v_version_breadcrumbs _pages_v_version_breadcrumbs_doc_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v_version_breadcrumbs
    ADD CONSTRAINT _pages_v_version_breadcrumbs_doc_id_pages_id_fk FOREIGN KEY (doc_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _pages_v_version_breadcrumbs _pages_v_version_breadcrumbs_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v_version_breadcrumbs
    ADD CONSTRAINT _pages_v_version_breadcrumbs_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._pages_v(id) ON DELETE CASCADE;


--
-- Name: _pages_v _pages_v_version_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v
    ADD CONSTRAINT _pages_v_version_meta_image_id_media_id_fk FOREIGN KEY (version_meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _pages_v _pages_v_version_parent_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._pages_v
    ADD CONSTRAINT _pages_v_version_parent_id_pages_id_fk FOREIGN KEY (version_parent_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _posts_v _posts_v_parent_id_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_parent_id_posts_id_fk FOREIGN KEY (parent_id) REFERENCES public.posts(id) ON DELETE SET NULL;


--
-- Name: _posts_v _posts_v_version_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_version_author_id_users_id_fk FOREIGN KEY (version_author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: form_notifications_notification form_notifications_notification_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_notifications_notification
    ADD CONSTRAINT form_notifications_notification_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.form(id) ON DELETE CASCADE;


--
-- Name: home home_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT home_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: menu_item menu_item_parent_id_menu_item_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_parent_id_menu_item_id_fk FOREIGN KEY (parent_id) REFERENCES public.menu_item(id) ON DELETE SET NULL;


--
-- Name: menu_item_rels menu_item_rels_pages_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_rels
    ADD CONSTRAINT menu_item_rels_pages_fk FOREIGN KEY (pages_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: menu_item_rels menu_item_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_rels
    ADD CONSTRAINT menu_item_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.menu_item(id) ON DELETE CASCADE;


--
-- Name: menu_item_rels menu_item_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_rels
    ADD CONSTRAINT menu_item_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: pages pages_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pages_breadcrumbs pages_breadcrumbs_doc_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages_breadcrumbs
    ADD CONSTRAINT pages_breadcrumbs_doc_id_pages_id_fk FOREIGN KEY (doc_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: pages_breadcrumbs pages_breadcrumbs_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages_breadcrumbs
    ADD CONSTRAINT pages_breadcrumbs_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pages pages_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: pages pages_parent_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_parent_id_pages_id_fk FOREIGN KEY (parent_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: payload_jobs_log payload_jobs_log_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_jobs_log
    ADD CONSTRAINT payload_jobs_log_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.payload_jobs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_form_field_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_form_field_fk FOREIGN KEY (form_field_id) REFERENCES public.form_field(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_form_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_form_fk FOREIGN KEY (form_id) REFERENCES public.form(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_menu_item_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_menu_item_fk FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_navigation_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_navigation_fk FOREIGN KEY (navigation_id) REFERENCES public.navigation(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pages_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pages_fk FOREIGN KEY (pages_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_submissions_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_submissions_fk FOREIGN KEY (submissions_id) REFERENCES public.submissions(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_user_accounts_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_user_accounts_fk FOREIGN KEY (user_accounts_id) REFERENCES public.user_accounts(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_user_sessions_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_user_sessions_fk FOREIGN KEY (user_sessions_id) REFERENCES public.user_sessions(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_user_verifications_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_user_verifications_fk FOREIGN KEY (user_verifications_id) REFERENCES public.user_verifications(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_form_id_form_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_form_id_form_id_fk FOREIGN KEY (form_id) REFERENCES public.form(id) ON DELETE SET NULL;


--
-- Name: user_accounts user_accounts_user_id_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_user_id_id_users_id_fk FOREIGN KEY (user_id_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_sessions user_sessions_user_id_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_id_users_id_fk FOREIGN KEY (user_id_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users_sessions users_sessions_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict ldrqz5BoSiuvMbhW14sy9zIt3dtfiToQK4xnIql3XaOde8yfpGaf0fqJgppFvnl

